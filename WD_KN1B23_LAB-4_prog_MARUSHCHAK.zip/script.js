document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    try {
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const donation = document.getElementById('donation').value;

        if (!name || !email || !donation) {
            throw new Error('All fields are required!');
        }

        const formData = {
            name: name,
            email: email,
            donation: donation
        };

        console.log('Form data:', formData);
        alert('Thank you for your registration and donation!');
    } catch (error) {
        alert('Error: ' + error.message);
    }
});
